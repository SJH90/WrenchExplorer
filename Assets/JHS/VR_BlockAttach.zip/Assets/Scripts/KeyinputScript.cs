﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyinputScript : MonoBehaviour {

    public GameObject tStage;
    public float rotSpeed;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        //Vector3 rot = tStage.transform.rotation.eulerAngles;
        tStage.transform.Rotate(new Vector3(vertical, -horizontal, 0.0f) * rotSpeed,Space.World);



        if (Input.GetButtonDown("Jump"))
        {
            PosReset();
        }
    }

    public void PosReset()
    {
        tStage.transform.rotation = Quaternion.Euler(Vector3.zero);
    }
}
