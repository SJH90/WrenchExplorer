﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EditManagerScript : MonoBehaviour {

    
    public struct listObject
    {
        public int type;       //1=cube, 2=fixed wheel, 3=hinged wheel
        public Vector3 pos;
        public Vector3 rot;

        public listObject(int type, Vector3 pos, Vector3 rot)
        {
            this.type = type; this.pos = pos; this.rot = rot;
        }
    }


    public List<listObject> Objectlist;
    public GameObject cube;
    public GameObject fixedwheel;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Y))
        {
            SaveObjects();
        }
        if(Input.GetKeyDown(KeyCode.U))
        {
            LoadObjects();
        }
    }

    
    public void SaveObjects()
    {
        Objectlist = new List<listObject>();
        Objectlist.Clear();
        foreach(Transform child in transform)
        {
            ObjectScript os = child.gameObject.GetComponent<ObjectScript>();
            switch (child.name)
            {
                case "Cube":
                case "Cube(Clone)":
                    Objectlist.Add(new listObject(1, os.pos, os.rot));
                    break;
                case "Fixed Wheel":
                case "Fixed Wheel(Clone)":
                    Objectlist.Add(new listObject(2, os.pos, os.rot));
                    break;

            }
        }
    }

    public void LoadObjects()
    {
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }

        GameObject ec = Instantiate(cube);
        ec.name = "Cube";
        ec.GetComponent<ObjectScript>().isEssential = true;
        ec.transform.parent = transform;
        ec.transform.localPosition = Objectlist[0].pos;
        ec.transform.localRotation = Quaternion.Euler(Objectlist[0].rot);

        for (int i=1; i<Objectlist.Count; i++)
        {
            GameObject newObject;
            if(Objectlist[i].type == 1)
            {
                newObject = Instantiate(cube);
            }else
            {
                newObject = Instantiate(fixedwheel);
            }
            newObject.transform.parent = transform;
            newObject.transform.localPosition = Objectlist[i].pos;
            newObject.transform.localRotation = Quaternion.Euler(Objectlist[i].rot);
        }
    }
}
