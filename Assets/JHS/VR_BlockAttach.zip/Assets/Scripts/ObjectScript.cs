﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectScript : MonoBehaviour {

    public GameObject shaded;

    public bool isEssential;

    public Vector3 pos;
    public Vector3 rot;

	// Use this for initialization
	void Start () {
	    	
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void EnableAddBlock()
    {
        foreach (Transform child in transform)
        {
            if (child.transform.CompareTag("AddBlock"))
            {
                child.gameObject.SetActive(true);
            }
        }
    }
    public void DisableAddBlock()
    {
        foreach (Transform child in transform)
        {
            if (child.transform.CompareTag("AddBlock"))
            {
                child.gameObject.SetActive(false);
            }
        }
    }
    public void EnableDelBlock()
    {
        foreach (Transform child in transform)
        {
            if (child.transform.CompareTag("DelBlock"))
            {
                child.gameObject.SetActive(true);
            }
        }
    }
    public void DisableDelBlock()
    {
        foreach (Transform child in transform)
        {
            if (child.transform.CompareTag("DelBlock"))
            {
                child.gameObject.SetActive(false);
            }
        }
    }
}
