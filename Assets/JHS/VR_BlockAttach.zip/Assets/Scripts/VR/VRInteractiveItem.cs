﻿using UnityEngine;
using System.Collections;
using System;

public class VRInteractiveItem : MonoBehaviour {
    
    public event Action OnEnter;
    public event Action OnOver;
    public event Action OnExit;

    public event Action OnBtnA;
    public event Action OnBtnB;
    
    public void Enter()
    {
        if (OnEnter != null)
            OnEnter();
    }
    public void Over()
    {
        if (OnOver != null)
            OnOver();
    }
    public void Exit()
    {
        if (OnExit != null)
            OnExit();
    }
    public void BtnA()
    {
        if (OnBtnA != null)
            OnBtnA();
    }
    public void BtnB()
    {
        if (OnBtnB != null)
            OnBtnB();
    }
}
