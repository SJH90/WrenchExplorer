﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;


public class VREyeRaycast : MonoBehaviour {

    public GameObject cube;

    public GameObject stage;

    [SerializeField]    private VRInput m_VRInput;
    [SerializeField]    private Transform m_Camera;
    [SerializeField]    private Transform m_Reticle;

    private VRInteractiveItem m_CurrentInteractiveItem;

    private GameObject CurrObject;  //현재 선택된/배치할 오브젝트
    private GameObject CurrShaded;  //현재 선택된 오브젝트의 커서용 투명한 오브젝트

    public Text worldText;  //텍스트

    /*
     * 디버깅용 오브젝트
     *
     *
     */

    public GameObject Object1;  //처음 CurrObject로 설정할 오브젝트(임시)
    public GameObject Object2;
    public GameObject Object3;
    public GameObject Object4;
    public GameObject delObject = null;

    public Vector3 currentRotation = Vector3.zero;
    


    // Use this for initialization
    void Awake   ()
    {
        ObjectChange(Object1);

        //m_VRInput.OnSwipe += HandleSwipe;
        m_VRInput.OnClick += ButtonDown;
        m_VRInput.OnCancel += HandleBtnB;
    }
	
	// Update is called once per frame
	void Update () {
        //EyeRaycast();
        AddBlockRaycast();

        KeyInput();

        if(CurrObject != null)
        {
            worldText.text = CurrObject.name.ToString();
        }else
        {
            worldText.text = "Del";
        }
        
	}

    private void KeyInput()
    {
        if (Input.GetKeyDown(KeyCode.Keypad1))
        {
            ObjectChange(Object1);
        }
        if (Input.GetKeyDown(KeyCode.Keypad2))
        {
            ObjectChange(Object2);
        }
        if (Input.GetKeyDown(KeyCode.Keypad3))
        {
            ObjectChange(delObject);
        }

        if (Input.GetKeyDown(KeyCode.J))
        {
            int y = (int)currentRotation.y;
            y = (y + 90) % 360;
            currentRotation = new Vector3(currentRotation.x, y, currentRotation.z);
        }
        if (Input.GetKeyDown(KeyCode.K))
        {
            int x = (int)currentRotation.x;
            x = (x + 90) % 360;
            currentRotation = new Vector3(x, currentRotation.y, currentRotation.z);
        }
        if (Input.GetKeyDown(KeyCode.L))
        {
            int y = (int)currentRotation.y;
            y = (y - 90) % 360;
            currentRotation = new Vector3(currentRotation.x, y, currentRotation.z);
        }
        if (Input.GetKeyDown(KeyCode.I))
        {
            int x = (int)currentRotation.x;
            x = (x - 90) % 360;
            currentRotation = new Vector3(x, currentRotation.y, currentRotation.z);
        }

    }


    private void EyeRaycast()
    {
        RaycastHit hit;
        Ray ray = new Ray(m_Camera.position, m_Camera.forward);

        VRInteractiveItem interactible;

        Vector3 hitpoint;

        if (Physics.Raycast(ray, out hit, 500f))
        {
            hitpoint = hit.point;

            interactible = hit.collider.GetComponent<VRInteractiveItem>();
        }
        else
        {
            hitpoint = Camera.main.transform.position + Camera.main.transform.forward * 5;
            interactible = null;
        }

        m_Reticle.position = Vector3.Lerp(Camera.main.transform.position, hitpoint, 0.9f);
        m_Reticle.localScale = new Vector3(0.01f, 0.01f, 0.01f) * Vector3.Distance(Camera.main.transform.position, m_Reticle.position);

        if (m_CurrentInteractiveItem != interactible)
        {
            if (m_CurrentInteractiveItem != null)
                m_CurrentInteractiveItem.Exit();

            m_CurrentInteractiveItem = interactible;

            if (m_CurrentInteractiveItem != null)
            {
                m_CurrentInteractiveItem.Enter();
                FuncMouseEnter();
            }

        }
        else
        {
            if (m_CurrentInteractiveItem != null)
                m_CurrentInteractiveItem.Over();
        }

    }

    private void AddBlockRaycast() 
    {
        //오브젝트가 붙을 장소를 보여주는 메소드

        RaycastHit hit;
        Ray ray = new Ray(m_Camera.position, m_Camera.forward);
        int layerMask = 1 << LayerMask.NameToLayer("AddBlock");

        if (Physics.Raycast(ray, out hit, 500f, layerMask))
        {
            if(CurrShaded != null)
            {
                CurrShaded.SetActive(true);
                CurrShaded.transform.parent = stage.transform;
                CurrShaded.transform.position = hit.transform.position;
                CurrShaded.transform.localRotation = Quaternion.Euler(currentRotation);
            }
        }
        else
        {
            if(CurrShaded != null)
            {
                CurrShaded.SetActive(false);
            }
            
        }
    }

    void ObjectChange(GameObject selectedObject)
    {
        if(selectedObject != null)
        {
            if(CurrShaded != null)
            {
                CurrShaded.gameObject.SetActive(false);
            }
            

            CurrObject = selectedObject;
            CurrShaded = CurrObject.GetComponent<ObjectScript>().shaded;

            GameObject shaded = Instantiate(CurrShaded);
            CurrShaded = shaded;
        }
        else
        {
            CurrShaded.gameObject.SetActive(false);

            CurrObject = null;
            CurrShaded = null;
        }
    }
    void FuncMouseEnter()
    {
        if(CurrObject != null)
        {
        }
        else
        {

        }
    }

    void ButtonDown()
    {
        //오브젝트를 붙이는 메소드

        if (CurrObject != null)
        {
            RaycastHit hit;
            Ray ray = new Ray(m_Camera.position, m_Camera.forward);
            int layerMask = 1 << LayerMask.NameToLayer("AddBlock");

            if (Physics.Raycast(ray, out hit, 500f, layerMask))
            {
                print("true");
                Transform currentObject = hit.transform.GetComponentInParent<ObjectScript>().transform;

                GameObject newcube = Instantiate(CurrObject);
                newcube.transform.parent = stage.transform;
                newcube.transform.position = hit.transform.position;
                newcube.transform.localRotation = Quaternion.Euler(currentRotation);

                char delimiterChars = ' ';
                string[] words = hit.transform.name.Split(delimiterChars);

                switch (words[0])
                {
                    case "x":
                        if (string.Compare(words[1], "Pos") == 0)
                            newcube.GetComponent<ObjectScript>().pos = currentObject.GetComponent<ObjectScript>().pos + new Vector3(1, 0, 0);
                        else
                            newcube.GetComponent<ObjectScript>().pos = currentObject.GetComponent<ObjectScript>().pos + new Vector3(-1, 0, 0);
                        break;
                    case "y":
                        if (string.Compare(words[1], "Pos") == 0)
                            newcube.GetComponent<ObjectScript>().pos = currentObject.GetComponent<ObjectScript>().pos + new Vector3(0, 1, 0);
                        else
                            newcube.GetComponent<ObjectScript>().pos = currentObject.GetComponent<ObjectScript>().pos + new Vector3(0, -1, 0);
                        break;
                    case "z":
                        if (string.Compare(words[1], "Pos") == 0)
                            newcube.GetComponent<ObjectScript>().pos = currentObject.GetComponent<ObjectScript>().pos + new Vector3(0, 0, 1);
                        else
                            newcube.GetComponent<ObjectScript>().pos = currentObject.GetComponent<ObjectScript>().pos + new Vector3(0, 0, -1);
                        break;
                }

                newcube.GetComponent<ObjectScript>().rot = currentRotation;
            }
        }
        else
        {
            RaycastHit hit;
            Ray ray = new Ray(m_Camera.position, m_Camera.forward);
            int layerMask = 1 << LayerMask.NameToLayer("DelBlock");

            if (Physics.Raycast(ray, out hit, 500f, layerMask))
            {
                print("del");
                Transform currentObject = hit.transform.GetComponentInParent<ObjectScript>().transform;
                if(currentObject.GetComponent<ObjectScript>().isEssential != true)
                {
                    Destroy(currentObject.gameObject);
                }else
                {
                    print("You Cannot destroy essential block");
                }
            }
        }
    }
    void HandleBtnB()
    {

    }

    void HandleSwipe(VRInput.SwipeDirection swipe)
    {

    }

}
